Run

npm install

and 

node index.js
