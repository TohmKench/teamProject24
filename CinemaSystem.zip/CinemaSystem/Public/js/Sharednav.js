$("document").ready(function () {

$("#myDiv").append(`
<nav class="bg-secondary py-2">
<div class="container">
    <ul class="nav justify-content-center">
        <li class="nav-item"><a class="nav-link text-white" href="home.html">Home</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="#">Movies</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="#">Schedule</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="#">Tickets</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="#">Contact Us</a></li>
    </ul>
</div>
</nav>`
);

});