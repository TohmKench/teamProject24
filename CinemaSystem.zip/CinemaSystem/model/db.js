var mysql = require('mysql');

var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '',
  database : 'rwc2023'
});

connection.connect(function(err){
	if(err) throw err;
	console.log(`Sucessfully connected to MySQL database rwc2023`);
});



// getCompanies
exports.getVenues = function(req,res){

	connection.query("SELECT * FROM `venues` ORDER BY `venues`.`name` ASC ", function(err, rows, fields) {
	  if (err) throw err;

	  res.send(JSON.stringify(rows));
	  
	});
	
}


// getUsersByID
exports.getTeams = function(req,res){

	connection.query(`select * from teams`, function(err, rows, fields) {
	  if (err) throw err;

	  res.send(JSON.stringify(rows));
	  
	});
	
}

exports.getTeamsA = function(req,res){

	connection.query(`SELECT pool , team_name FROM pools where pool = 'A';`, function(err, rows, fields) {
	  if (err) throw err;

	  res.send(JSON.stringify(rows));
	  
	});
	
}

exports.getTeamsPool = function(req,res){

	connection.query("SELECT pools.pool, teams.id, teams.name FROM teams, pools WHERE teams.name = pools.team_name ORDER BY `teams`.`name` ASC	;", function(err, rows, fields) {
	  if (err) throw err;

	  res.send(JSON.stringify(rows));
	  
	});
	
}

exports.getTeamsPool2 = function(req,res){

	connection.query("SELECT pools.pool, teams.id, teams.name FROM teams, pools WHERE teams.name = pools.team_name ORDER BY `pools`.`pool` ASC	;", function(err, rows, fields) {
	  if (err) throw err;

	  res.send(JSON.stringify(rows));
	  
	});}

	exports.getPlayers = function(req,res){

		connection.query("SELECT teams.id as teamID, players.name as playerName, teams.name as teamName FROM `players`, `teams` WHERE teams.id = players.team_id; ", function(err, rows, fields) {
		  if (err) throw err;
	
		  res.send(JSON.stringify(rows));
		  
		});
		
	}


	exports.getResults = function(req,res){

		connection.query(`select * from results ORDER BY date, time`, function(err, rows, fields) {
		  if (err) throw err;
	
		  res.send(JSON.stringify(rows));
		  
		});
		
	}

	exports.getResultsByTeam = function(req,res){

		connection.query(`select * from results ORDER BY date, time`, function(err, rows, fields) {
		  if (err) throw err;
	
		  res.send(JSON.stringify(rows));
		  
		});
		
	}

	exports.getPlayerStats = function(req,res){

		connection.query(`SELECT player_points.player_name, player_points.team_id, player_points.team_name, player_points.points, player_tackles.tackles FROM player_points , player_tackles where player_points.player_id = player_tackles.player_id order by points desc;
		`, function(err, rows, fields) {
		  if (err) throw err;
	
		  res.send(JSON.stringify(rows));
		  
		});
		
	}

	exports.getPools = function(req,res){

		connection.query(`select * from pools ORDER BY pool, position asc`, function(err, rows, fields) {
		  if (err) throw err;
	
		  res.send(JSON.stringify(rows));
		  
		});
		
	}
	
	exports.getPools2 = function(req,res){

		connection.query("SELECT DISTINCT pools.team_name, pools.pool, teams.id FROM pools JOIN teams ON pools.team_name = teams.name ORDER BY pools.pool ASC;", function(err, rows, fields) {
		  if (err) throw err;
	
		  res.send(JSON.stringify(rows));
		  
		});
		
	}
	
	exports.getResults36 = function(req,res){

		connection.query("SELECT * FROM `results` where team1_id = '36' || team2_id = '36';", function(err, rows, fields) {
		  if (err) throw err;
	
		  res.send(JSON.stringify(rows));
		  
		});

		
		
	}

	exports.getUsers = function(req,res){

		connection.query("SELECT * FROM `users` ;", function(err, rows, fields) {
		  if (err) throw err;
	
		  res.send(JSON.stringify(rows));
		  
		});
	}
	

// deleteCompany
